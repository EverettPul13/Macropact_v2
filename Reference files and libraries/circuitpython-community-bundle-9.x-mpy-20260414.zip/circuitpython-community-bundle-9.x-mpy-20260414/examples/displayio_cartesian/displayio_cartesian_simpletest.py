# SPDX-FileCopyrightText: 2017 Scott Shawcroft, written for Adafruit Industries
# SPDX-FileCopyrightText: Copyright (c) 2025 Jose David M. for circuitpython
#
# SPDX-License-Identifier: Unlicense
